﻿using System.Windows;

namespace Laba_14
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {

    }
}
